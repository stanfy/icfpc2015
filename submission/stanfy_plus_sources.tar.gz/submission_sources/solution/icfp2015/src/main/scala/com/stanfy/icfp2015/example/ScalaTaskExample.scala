package com.stanfy.icfp2015.example

/**
 * Created by ptaykalo on 8/1/15.
 */
object ScalaTaskExample {

  def multiply(op1: Int, op2: Int): Int = {
    op1 * op2
  }

}
