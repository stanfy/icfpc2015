package com.stanfy.icfp2015;

/**
 * Created by ptaykalo on 8/1/15.
 */
public class TaskExample {

  public static final int add(int parameter, int anotherParameter) {
    return parameter + anotherParameter;
  }

}
