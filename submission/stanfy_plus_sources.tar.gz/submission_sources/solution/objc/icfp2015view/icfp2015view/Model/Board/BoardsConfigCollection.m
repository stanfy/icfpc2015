//
// Created by Paul Taykalo on 8/7/15.
// Copyright (c) 2015 Stanfy LLC. All rights reserved.
//

#import "BoardsConfigCollection.h"


@implementation BoardsConfigCollection {

}

+ (NSString * )problem0 {
    return nil;
}
@end