//
//  clilibrary.h
//  clilibrary
//
//  Created by Paul Taykalo on 8/7/15.
//  Copyright (c) 2015 Stanfy LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface clilibrary : NSObject

@end
