# Dependencies

1. Node.js server
2. npm install commander