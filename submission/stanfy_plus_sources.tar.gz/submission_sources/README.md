# Dependencies

1. Mac OS X 10.10 environment
2. xcode 6.4
3. xcode command line tools